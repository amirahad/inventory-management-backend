Step-by-step instructions on how to install your project locally.

```bash
# Clone the repository
git clone https://github.com/amirahad/inventory-management-backend.git

# Navigate to the project directory
cd inventory-management-backend

# Install dependencies
yarn

# Start 
yarn dev

